






function Vote(){



    let survey = document.getElementById("survey");
    survey.classList.add("hidden");
    let thanksBanner = document.getElementById("postSurveyPrompt").classList.remove("hidden");


}